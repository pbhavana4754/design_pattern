package com.epam7.designpatterns;

public interface Order {
	   void execute();
	}