package com.epam7.designpatterns;


public interface Shape {
	   void draw();
	}
